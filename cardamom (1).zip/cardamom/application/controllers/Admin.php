<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
    public function login(){

        $this->load->view('admin/login');
    }
    public function testLoging(){
        $data['admin_email']=$this->input->post('admin_email',true);
        $data['admin_pass']=($this->input->post('admin_pass',true));
        if(!empty($data['admin_email']) && !empty($data['admin_pass'])){
               $permitlogin=$this->modAdmin->permitlogin($data);
               
               if (count($permitlogin)==1) {
                 
                     $forSession=array(
                        'admin_id'=> $permitlogin[0]['admin_id'],
                        'admin_name'=> $permitlogin[0]['admin_name']
                        
                );
                    $this->session->set_userdata($forSession);
                    if ($this->session->userdata('admin_id')) {
                        
                        redirect('Admin/index');
                    }
                    else{
                        echo "Session not Created";
                    }
                    
                }
                else{
                    $this->session->set_flashdata('class','alert-danger');
                    $this->session->set_flashdata('message','Please Check Your Email or Password or may be your email is not verified');
                    redirect('Admin/index');

                }
    }
    }
	public function index()
	{
        if ($this->session->userdata('admin_id')) {
            $this->load->view('admin/header');
            $this->load->view('admin/home');
            $this->load->view('admin/footer');
        }
        else{
            $this->load->view('admin/login');
        }
		
	}

    public function addPricing(){

            $this->load->view('admin/header');
            $this->load->view('admin/addPricing');
            $this->load->view('admin/footer');

    }

	public function addCat(){

		$this->load->view('admin/header');
		$this->load->view('admin/addCategory');

	}

	public function addCategory(){

		$data['cat_name']=$this->input->post('cat_name');
		$admin=$this->modAdmin->checkCategory($data);
		if ($admin->num_rows()==0) {
			$addData=$this->modAdmin->addCategory($data);
			$this->session->set_flashdata('class','alert-success');
            $this->session->set_flashdata('message','Category Added Successfully');
            redirect('Admin/addCat');
			
		}
		else{
			$this->session->set_flashdata('class','alert-danger');
            $this->session->set_flashdata('message','This Category Is Already Exists');
            redirect('Admin/addCat');
		}

	}
    public function addPackage(){
        $data['package_name']=$this->input->post('package_name');
        $data['price']=$this->input->post('price');
        $data['feature1']=$this->input->post('feature1');
        $data['feature2']=$this->input->post('feature2');
        $data['feature3']=$this->input->post('feature3');
        $data['feature4']=$this->input->post('feature4');
        $data['feature5']=$this->input->post('feature5');
        $admin=$this->modAdmin->checkPackage($data);
        if ($admin->num_rows()==0) {
            $addData=$this->modAdmin->addPackage($data);
            $this->session->set_flashdata('class','alert-success');
            $this->session->set_flashdata('message','Package Added Successfully');
            redirect('Admin/addPricing');
            
        }
        else{
            $this->session->set_flashdata('class','alert-danger');
            $this->session->set_flashdata('message','This Category Is Already Exists');
            redirect('Admin/addPricing');
        }

    }
    public function contactFormSubmission(){

        $data['customer_name']=$this->input->post('customer_name');
        $data['customer_email']=$this->input->post('customer_email');
        $data['customer_message']=$this->input->post('customer_message');

        
        if ($data['customer_message']) {
            $addData=$this->modAdmin->addMessage($data);
            $this->session->set_flashdata('class','alert-success');
            $this->session->set_flashdata('message','Package Added Successfully');
            redirect('Welcome/index');
            
        }
        else{
            $this->session->set_flashdata('class','alert-danger');
            $this->session->set_flashdata('message','This Category Is Already Exists');
            redirect('Welcome/index');
        }

    }
	public function viewCat(){
        $data['viewCat'] = $this->modAdmin->fetch_category();
		$this->load->view('admin/header');
		$this->load->view('admin/viewCategory',$data);

	}
    public function viewPricing(){
        $data['viewPak'] = $this->modAdmin->fetch_pricing();
        $this->load->view('admin/header');
        $this->load->view('admin/viewPakage',$data);


    }
    public function viewOrder(){
        $data['viewOrder'] = $this->modAdmin->fetch_order();
        $this->load->view('admin/header');
        $this->load->view('admin/viewOrder',$data);

    }

	public function editCat($cat_id){
        
		$data['category']=$this->modAdmin->chekCategoryById($cat_id);
		if (count($data['category'])==1) {
            $this->load->view('admin/header');
            $this->load->view('admin/editCategory',$data);
            $this->load->view('admin/footer');
            }
            else{
            
            $this->session->set_flashdata('class','alert-danger');
            $this->session->setFlashData('alert-danger','Category not found');
            redirect('admin/viewCat');

            }

	}
    public function makeOrderReady($id){

        $this->modAdmin->makeOrderReady($id);
        redirect('admin/viewOrder');

    }
    public function makeOrderForDelete($id){

        $this->modAdmin->makeOrderForDelete($id);
        redirect('admin/viewOrder');

    }
    public function deleteOrder($id){

        $this->modAdmin->deleteOrder($id);
        $this->session->set_flashdata('class','alert-success');
        $this->session->set_flashData('message','Order Deleted Successfully');
                
        redirect('admin/viewOrder');

    }

    public function editPak($price_id){
        $data['package']=$this->modAdmin->chekPackageById($price_id);
        if (count($data['package'])==1) {
            $this->load->view('admin/header');
            $this->load->view('admin/editPackage',$data);
            $this->load->view('admin/footer');
            }
            else{
            
            $this->session->set_flashdata('class','alert-danger');
            $this->session->setFlashData('alert-danger','Category not found');
            redirect('admin/viewPricing');

            }


    }

	public function updateCategory(){
		$data['cat_name']=$this->input->post('cat_name',true);
        $data['cat_id']=$this->input->post('cat_id',true);
        

        if (!empty($data['cat_name'])&& isset($data['cat_id'])) {
        	
        	$reply=$this->modAdmin->updateCategory($data);

        	if ($reply) {

        		$this->session->set_flashdata('class','alert-success');
                $this->session->set_flashData('message','Category Updated Successfully');
                redirect('admin/viewCat');

        	}
        }
	}

    public function updatePackage(){

        $data['package_name']=$this->input->post('package_name');
        $data['price_id']=$this->input->post('price_id');
        $data['price']=$this->input->post('price');
        $data['feature1']=$this->input->post('feature1');
        $data['feature2']=$this->input->post('feature2');
        $data['feature3']=$this->input->post('feature3');
        $data['feature4']=$this->input->post('feature4');
        $data['feature5']=$this->input->post('feature5');
        


        if (!empty($data['price_id'])) {
            
            $reply=$this->modAdmin->updatePackage($data);

            if ($reply) {

                $this->session->set_flashdata('class','alert-success');
                $this->session->set_flashData('message','Package Updated Successfully');
                redirect('admin/viewPricing');

            }
        }
       

    }

	public function deleCat($id){
            if(!empty($id) && isset($id)){
                  $data=$this->modAdmin->deleteCategory($id);
                  if ($data) {
                    $this->session->set_flashdata('class','alert-success');
                        $this->session->set_flashdata('message','Category Delated');
                        redirect('admin/viewCat');
                    
                  }
                  else{
                   $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Category not found');
                    redirect('admin/viewCat');
                  }
                }
                else{
                    $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Category Can not found');
                    redirect('admin/viewCat');


                }

        }
    public function delePak($id){
        if(!empty($id) && isset($id)){
                  $data=$this->modAdmin->deletePackage($id);
                  if ($data) {
                    $this->session->set_flashdata('class','alert-success');
                        $this->session->set_flashdata('message','Package Delated');
                        redirect('admin/viewPricing');
                    
                  }
                  else{
                   $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Package not found');
                    redirect('admin/viewPricing');
                  }
                }
                else{
                    $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Package Can not found');
                    redirect('admin/viewPricing');


                }

    }
    public function addProduct(){
            $data['viewCat'] = $this->modAdmin->fetch_category();
    	    $this->load->view('admin/header');
            $this->load->view('admin/addProduct',$data);
            $this->load->view('admin/footer');

    }

    public function addFood(){

    	$data['food_name']=$this->input->post('food_name');
    	$data['food_category']=$this->input->post('food_category');
    	$data['stock']=$this->input->post('stock');
    	$data['price']=$this->input->post('price');

    	if (!empty($data['food_name'])) {
                    $path=realpath('assets/images/');
                    $config['upload_path']=$path;
                    $config['allowed_types']='gif|png|jpg|jpeg';
                    $new_name = time().$_FILES["food_pic"]['name'];
                    $config['file_name'] = $new_name;

                    $this->load->library('upload',$config);
                    if (!$this->upload->do_upload('food_pic')) {
                        //$error=$this->upload->display_errors();
                        
                        // echo $error;
                    }
                    else{
                        $fileName=$this->upload->data();
                        $data['food_pic']=$fileName['file_name'];
                        

                    }
                }
        $addFood=$this->modAdmin->addProduct($data);


        if ($addFood) {
        	$this->session->set_flashdata('class','alert-success');
            $this->session->set_flashdata('message','Food Added Successfully');
                    
        	redirect('Admin/addProduct');
        }




    }
    public function viewProduct(){

        //new 
       $config = array();
       $config["base_url"] = base_url() . "admin/viewProduct";
       $config["total_rows"] = $this->modAdmin->get_count();
       $config["per_page"] = 5;
       $config["uri_segment"] = 0;
       $this->pagination->initialize($config);
       $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
       $data["viewFood"] = $this->modAdmin->
           fetch_food($config["per_page"], $page);
       $data['viewCat'] = $this->modAdmin->fetch_category();
       $data["links"] = $this->pagination->create_links();
       $this->load->view('admin/header');
       $this->load->view('admin/viewProduct',$data);
       $this->load->view('admin/footer');



        //new

     /*   $config = array();
        $config["base_url"] = base_url() . "admin/viewProduct";
        $config["total_rows"] = $this->modAdmin->get_count();
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;

        $data["links"] = $this->pagination->create_links();

        $data['viewFood'] = $this->modAdmin->fetch_food($config["per_page"], $page);
    	$data['viewCat'] = $this->modAdmin->fetch_category();
        */
    	    

    }
    public function editFood($id){
    	 $data['thisFoodInfo']=$this->modAdmin->chekFoodById($id);
    	 $data['viewCat'] = $this->modAdmin->fetch_category();
    	 $this->load->view('admin/header');
         $this->load->view('admin/editFood',$data);
         $this->load->view('admin/footer');


    }
    public function updateFood(){

                $data['food_name']=$this->input->post('food_name',true);
                $data['food_category']=$this->input->post('food_category',true);
                $data['stock']=$this->input->post('stock',true);
                $data['price']=$this->input->post('price',true);
                $data['food_id']=$this->input->post('food_id',true); 
                if (!empty($data['food_name'])&& isset($data['food_category'])&& isset($data['stock'])) {
                    if(isset($_FILES['food_pic']) && is_uploaded_file($_FILES['food_pic']['tmp_name'])){
                    $path=realpath('assets/images/');
                    $config['upload_path']=$path;
                    $config['allowed_types']='gif|png|jpg|jpeg';
                    $this->load->library('upload',$config);
                    if (!$this->upload->do_upload('food_pic')) {
                        $error=$this->upload->display_errors();
                        print_r($error);
                        exit();
                        $this->session->set_flashdata('class','alert-danger');
                        $this->session->set_flashdata('message','Food Updated Successfully');
               
                    }
                    else{
                        $fileName=$this->upload->data();
                        $data['food_pic']=$fileName['file_name'];
                        
                    }

                    }//Image Chaking Here
                    $reply=$this->modAdmin->updateProduct($data,$data['food_id']);
                    if ($reply) {
                        if (!empty($data['img']) && isset($data['img'])) {
                            if (file_exists($path.'/'.$oldimg)) {
                                unlink($path.'/'.$oldimg);
                            }
                        }
                $this->session->set_flashdata('class','alert-success');
                $this->session->set_flashdata('message','Food Updated Successfully');
                redirect('Admin/viewProduct');
                        
                    }
                    else{
                        setFlashData('alert-danger','You can not Food now','Admin/viewProduct');
                    }
                    # code...
                }
                else{
                    setFlashData('alert-danger','Please Check Every Field','Admin/viewProduct');

                }
           
    	
    }

    public function deleFood($food_id){

        if(!empty($food_id) && isset($food_id)){
                  $data=$this->modAdmin->deleteFood($food_id);
                  if ($data) {
                    $this->session->set_flashdata('class','alert-success');
                        $this->session->set_flashdata('message','Category Delated');
                        redirect('admin/viewProduct');
                    
                  }
                  else{
                   $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Category not found');
                    redirect('admin/viewProduct');
                  }
                }
                else{
                    $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Category Can not found');
                    redirect('admin/viewProduct');

                }

    }
    public function logout(){
        if ($this->session->userdata('admin_id')) {
                
                $this->session->set_userdata('admin_id','');
                $this->session->set_userdata('admin_name','');
                redirect('admin/login');
                
            }
            else{
                $this->session->set_flashdata('error','Please log in');
                redirect('admin/login');
               

            }
    }
    public function viewMessage(){
        $data['viewMessage'] = $this->modAdmin->fetch_Message();
        $this->load->view('admin/header');
        $this->load->view('admin/viewMessage',$data);


    }
    

   
}
