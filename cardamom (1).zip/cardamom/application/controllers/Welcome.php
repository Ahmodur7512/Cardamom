<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{    

		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();
		$data['viewPackage'] = $this->modAdmin->fetch_all_package();


		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/menu',$data);

		
		$this->load->view('frontend/about');
		$this->load->view('frontend/gallary');
		$this->load->view('frontend/chef');
		$this->load->view('frontend/pricing');
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');
	}

	public function about(){
		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();

		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		
		$this->load->view('frontend/about',$data);
		$this->load->view('frontend/gallary');
		$this->load->view('frontend/chef');
		$this->load->view('frontend/pricing');
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');

	}
	public function gallary(){
		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();

		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/gallary',$data);
		$this->load->view('frontend/chef');
		$this->load->view('frontend/pricing');
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');

	}
	public function chef(){
		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();

		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/chef',$data);
		$this->load->view('frontend/pricing');
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');
	}
	public function pricing(){
		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();
		$data['viewPackage'] = $this->modAdmin->fetch_all_package();

		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/pricing',$data);
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');


	}
	public function blog(){
		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();

		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/blog',$data);
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');

	}
	public function contact(){
		$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();

		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/contact',$data);
		$this->load->view('frontend/footer');

	}

	public function addToCart($id){

		$food_id=$id;
		$user_id=$this->session->userdata('user_id');
		$data=array(
            'food_id'=>$food_id,
            'user_id' =>$user_id
            
        );
        $checkCartExistance=$this->modAdmin->checkCartExistance($data);
        
        
        if ($checkCartExistance==0) {
        	$cart=$this->modAdmin->countToCart($data);
        if ($cart) {
        	redirect('Welcome/index');
        }
        }else{
        	$data['cartInfo'] = $this->modAdmin->fetch_cart_quantity_forUser($id,$user_id);
        	
        	$data['quant']=$data['cartInfo']->quant;
        	$data['cart_id']=$data['cartInfo']->cart_id;
        	
        	$cart=$this->modAdmin->updatecountToCart($data['quant'],$data['cart_id']);
        if ($cart) {
        	redirect('Welcome/index');
        }

        }
        

        


	}
	public function addToCartAsGuest($id){

		$food_id=$id;
		$data=array(
            'food_id'=>$food_id,
            'user_id' =>null,
            'guest'=>1
            
        );
        
        $checkCartExistance=$this->modAdmin->checkCartExistance($data);
        if ($checkCartExistance==0) {
        	$cart=$this->modAdmin->countToCart($data);
        if ($cart) {
        	redirect('Welcome/index');
        }

        }else{

        	$data['cartInfo'] = $this->modAdmin->fetch_cart_quantity($id);
        	
        	$data['quant']=$data['cartInfo']->quant;
        	$data['cart_id']=$data['cartInfo']->cart_id;
        	
        	$cart=$this->modAdmin->updatecountToCart($data['quant'],$data['cart_id']);
        if ($cart) {
        	redirect('Welcome/index');
        }

        }
        


	}
	

    public function login(){

    	$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/login');
		

    }
    public function registration(){

    	$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/registration');
		

    }
    public function registrationSubmission(){

		$data['user_name']=$this->input->post('user_name',true);
		$data['user_email']=$this->input->post('user_email',true);
		$data['user_password']=md5($this->input->post('user_password',true));

		$chkRegister=$this->modAdmin->chkRegister($data);

		if ($chkRegister==0) {
	    $addUser=$this->modAdmin->addUser($data);		
			
			if ($addUser) {
					$this->session->set_flashdata('class','alert-success');
					$this->session->set_flashdata('Successmessage','Your Are Registered Now');
					redirect('Welcome/registration');
                    
				}
		}
		else{
		    

			$this->session->set_flashdata('class','alert-danger');
			$this->session->set_flashdata('Usedmessage','Sorry! Your email is already used.');
			redirect('Welcome/registration');

		}


	}
	
	public function loginin(){
		$data['user_email']=$this->input->post('user_email',true);
        $data['user_password']=md5($this->input->post('user_password',true));
        if(!empty($data['user_email']) && !empty($data['user_password'])){
               $permitlogin=$this->modAdmin->user_permitlogin($data);
               if (count($permitlogin)==1) {
                 
                     $forSession=array(
                        'user_id'=> $permitlogin[0]['user_id'],
                        'user_name'=> $permitlogin[0]['user_name']
                        
                );
                    $this->session->set_userdata($forSession);
                    if ($this->session->userdata('user_id')) {
                    	
                        redirect('Welcome/index');
                    }
                    else{
                        echo "Session not Created";
                    }
                    
                }
                else{
                	$this->session->set_flashdata('class','alert-danger');
					$this->session->set_flashdata('Errormessage','Please Check Your Email or Password or may be your email is not verified');
					redirect('Welcome/registration');

                }
	}
}
public function logout(){
            
            if ($this->session->userdata('user_name')) {
                
                $this->session->set_userdata('user_id','');
                $this->session->set_userdata('user_name','');
                redirect('Welcome/index');
                
            }
            else{
                $this->session->set_flashdata('error','Please log in');
                redirect('Welcome/registration');
               

            }
        }

    public function seeCart(){

    $data['seeCart'] = $this->modAdmin->fetch_cart();
    $this->load->view('frontend/header');
	$this->load->view('frontend/navbar');
	$this->load->view('frontend/seeCart',$data);

    }
    public function seeCartAsGuest(){

    $data['seeCart'] = $this->modAdmin->fetch_cartAsGuest();
    $this->load->view('frontend/header');
	$this->load->view('frontend/navbar');
	$this->load->view('frontend/seeCart',$data);

    }
    public function deleFoodFromCart($id){
    	 if(!empty($id) && isset($id)){
                  $data=$this->modAdmin->deletecart($id);
                  if ($data) {
                    $this->session->set_flashdata('class','alert-success');
                        $this->session->set_flashdata('message','This Product Is Delated From Your Cart');
                        redirect('Welcome/seeCart');
                    
                  }
                  else{
                   $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Category not found');
                    redirect('Welcome/seeCart');
                  }
                }
                else{
                    $this->session->set_flashdata('class','alert-danger');
                   $this->session->set_flashdata('message','Category Can not found');
                    redirect('Welcome/seeCart');

                }
    }
    public function search()
 {
  $output = '';
  $query = '';
  if($this->input->post('query'))
  {
   $query = $this->input->post('query');
  }
  $data = $this->modAdmin->fetch_data($query);
  $output .= '
  
  ';
  if($data->num_rows() > 0)
  {
   foreach($data->result() as $row)
   {
   	
    $output .= '
    
    <div class="services-inner-box">

    <div class="ser-icon">
    <img src="'. base_url('assets/images/'.$row->food_pic) .'" class="img-fluid" alt="" />
    </div>

     
      <h2 style="color:black">'.$row->food_name.' </h2>
      <h3 style="color:black"> '.'$'.$row->price .'</h3>
      <a class="hvr-radial-in" href="" >Add To Cart</a>
      
      
	 </div>					
    
      
    ';
   }

  }
  else
  {
   $output .= '<tr>
       <td colspan="5">No Data Found</td>
      </tr>';
  }
  $output .='</div>';
  echo $output;
 }
 public function payment($id){

 	$data['total_price']=$id;
 	$this->load->view('frontend/header');
	$this->load->view('frontend/navbar');
	$this->load->view('frontend/payment',$data);
	$this->load->view('frontend/footer');

 }
 public function submitPayment(){

 	require_once('application/libraries/init.php');
    
        \Stripe\Stripe::setApiKey($this->config->item('stripe_secret'));
     
       $charge = \Stripe\Charge::create ([
                "amount" => 0.1,
                "currency" => "usd",
                "source" => $this->input->post('stripeToken'),
                "description" => "Test payment from webpreparations" 
        ]);
    $chargeJson = $charge->jsonSerialize();
        
        
  /*  for insert data in database start */
   $item_name       = "Premium Script Webpreparations";
   $item_number     = "PS123456";
   $item_price      = 0.1;
   $currency        = "usd";
   $order_id        = "SKA92712382139";
        
   $amount                  = $chargeJson['amount'];
   $balance_transaction     = $chargeJson['balance_transaction'];
   $currency                = $chargeJson['currency'];
   $status                  = $chargeJson['status'];
   if ($this->session->userdata('user_id')) {
   	$insert_data = array(
                    'user_id'          => $this->session->userdata('user_id')
                     );
        
        
  $this->modAdmin->insertOrder($insert_data);
              /*  for insert data in database close */
            
        $this->session->set_flashdata('success', 'Payment made successfully.');
             
        redirect('Welcome/index', 'refresh');
   }
   else{
   	$insert_data = array(
                    'user_id'          => null,
                    'guest'=>1
                     );
        
        
  $this->modAdmin->insertOrderAsGuest($insert_data);
              /*  for insert data in database close */
            
        $this->session->set_flashdata('success', 'Payment made successfully.');
             
        redirect('Welcome/index', 'refresh');
   }
        
        
  

 }
 public function payByCash($id){

 	if ($this->session->userdata('user_id')) {
 		$data['seeCart'] = $this->modAdmin->fetch_cart();

	    $this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/seeCart',$data);
	 	$insert_data = array(
	                    'user_id'=> $this->session->userdata('user_id')
	                     );
		  $this->modAdmin->insertOrderByCash($insert_data);
	    $this->session->set_flashdata('class','alert-success');
	    $this->session->set_flashdata('message','You have ordered some food by'." $".$id.' in cash');

	             
        redirect('Welcome/seeCart', 'refresh');

 	}
 	else{
 		$data['seeCart'] = $this->modAdmin->fetch_cart();

	    $this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/seeCart',$data);
	 	$insert_data = array(
	                    'guest'=> 1
	                     );
		  $this->modAdmin->insertGuestOrderByCash($insert_data);
	    $this->session->set_flashdata('class','alert-success');
	    $this->session->set_flashdata('message','You have ordered some food by'." $".$id.' in cash');
	    if ($this->session->userdata('guest')) {
                
                $this->session->set_userdata('guest','');
                
                
                
            }
	             
        redirect('Welcome/seeCart', 'refresh');


 	}

	 	
 }
 public function menuByCat($id){
 	$data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food_by_Category($id);
		$data['viewPackage'] = $this->modAdmin->fetch_all_package();


		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/menu',$data);

		
		$this->load->view('frontend/about');
		$this->load->view('frontend/gallary');
		$this->load->view('frontend/chef');
		$this->load->view('frontend/pricing');
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');

 }
 public function shoppingByGuest(){
 	
 	 $forSession=array(
                        'guest'=> 'Unknown'
                        
                );
 	 $this->session->set_userdata($forSession);

 	    $data['viewCat'] = $this->modAdmin->fetch_category();
		$data['viewFood'] = $this->modAdmin->fetch_all_food();
		$data['viewPackage'] = $this->modAdmin->fetch_all_package();


		$this->load->view('frontend/header');
		$this->load->view('frontend/navbar');
		$this->load->view('frontend/menu',$data);

		
		$this->load->view('frontend/about');
		$this->load->view('frontend/gallary');
		$this->load->view('frontend/chef');
		$this->load->view('frontend/pricing');
		$this->load->view('frontend/blog');
		$this->load->view('frontend/contact');
		$this->load->view('frontend/footer');
 	 
                

 }
}
