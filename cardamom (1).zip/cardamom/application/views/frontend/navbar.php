<p style="color:white">This example displays a simple translate button, with no text.</p>
<p><a style="color:white" translate="no" target="_top" href="https://codepen.io/kimone0915/pen/mdRMWxz">
Edit this code</a></p><br>


<div id="translation"></div>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=google_translate"></script>
<script>
function google_translate (){ 
    var opt = { 
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE, 
        pageLanguage: "en" 
    }; 
    new google.translate.TranslateElement( opt, "translation" ); 
} 

/*  
Display the scrollable list of languages. 
Related to the size of current browser. 
*/
addEventListener( "load", function(){ 
    if ( document.querySelector(".goog-te-menu-frame") ) { 
    
        document.getElementById( "translation" ).addEventListener( "click", function(){ 
            if ( this.id === "translation" ) scrollableLanguagesList(); 
        }); 
        addEventListener( "resize", function(){ 
            if ( "none" !== document.querySelector(".goog-te-menu-frame").style.display ) scrollableLanguagesList(); 
        }); 
    
    } 
}); 

function scrollableLanguagesList (){ 
    var 
     iframe = document.querySelector( ".goog-te-menu-frame" ), 
     doc = iframe.contentWindow.document, 
     div = doc.body.children[ 0 ], 
     table = div.children[ 0 ], 
     width = div.dataset.width || parseInt( div.style.width ), 
     rect, diff; 
    
    if ( ! div.dataset.width ) div.dataset.width = width; 
    
    if ( innerWidth < width ) { 
        rect = table.getBoundingClientRect(); 
        width = rect.right - rect.left; 
        diff = width - innerWidth; 
        
        div.style.width = ( width - diff - 24 ) + "px"; 
        div.style.padding = "4px 0 1em 4px"; 
        div.style.overflowX = "scroll"; 
    } 
    else { 
        div.style.width = "auto"; 
        div.style.padding = "4px"; 
        div.style.overflowX = "visible"; 
    } 
    
    rect = div.getBoundingClientRect(); 
    iframe.style.width = ( rect.right - rect.left ) + "px"; 
    iframe.style.height = ( rect.bottom - rect.top ) + "px"; 
} 
</script>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container-fluid">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">
			<img class="img-fluid" src="<?php echo base_url('assets/images/cardamomLogo.jpg') ?>" alt="" / style="width: 40%;">
		</a>

        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="flexbox">
  <div class="search">
    <div>
      <input type="text" placeholder="Search . . ." required placeholder="Search" name="search_text" id="search_text">
    </div>
  </div>
</div>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger active" href="<?php echo base_url('Welcome/index') ?>"><span>Menu</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="<?php echo base_url('Welcome/about') ?>"><span>About</span></a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="<?php echo base_url('Welcome/gallary') ?>"><span>Gallery</span></a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="<?php echo base_url('Welcome/chef') ?>"><span>Chef</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="<?php echo base_url('Welcome/pricing') ?>"><span>Pricing</span></a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="<?php echo base_url('Welcome/blog') ?>"><span>Blog</span></a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="<?php echo base_url('Welcome/contact') ?>"><span>Contect Us</span></a>
            </li>
        <li class="nav-item">
          <a href="<?php 
          if($this->session->userdata('user_id')){
            echo base_url('Welcome/seeCart');
          }elseif($this->session->userdata('guest')){
            echo base_url('Welcome/seeCartAsGuest');
          }
           ?>">
<span class="fa-stack fa-2x has-badge" data-count="<?php 

    if ($this->session->userdata('user_id')) {
        $count_cart=$this->modAdmin->count_cart_for_user($this->session->userdata('user_id'));
        if(!empty($count_cart)){
          echo sizeof($count_cart);
        }
        else{
          ?>
          0
          <?php
        }

    }elseif($this->session->userdata('guest')){
        $count_cart_for_guest=$this->modAdmin->count_cart_for_guest();
        if(!empty($count_cart_for_guest)){
          echo sizeof($count_cart_for_guest);
        }
        else{
          ?>
          0
          <?php
        }

      ?>
      
      <?php
}else{
    echo "0";
}
     ?>" href="#open-modal">
  <i class="fa fa-circle fa-stack-2x"></i>
  <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
</span>
   </a> 
    
  
  </div>            </li>

  <li class="nav-item">
    <?php 
    if ($this->session->userdata('user_id')) {
      
    ?>
    <div class="dropdown">
  <button onclick="myFunction()" class="dropbtn"><i class="fa fa-user"></i></button>
  <div id="myDropdown" class="dropdown-content">
    <a href="<?php echo base_url('Welcome/logout') ?>">Log out</a>
    <a href="#about">Profile</a>
  </div>
</div>
    
     
    
    <?php
     }
     ?>
  </li>
          </ul>
        </div>
      </div>
    </nav>