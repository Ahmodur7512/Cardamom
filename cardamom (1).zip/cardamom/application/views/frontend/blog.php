<div id="blog" class="section wb">
		<div class="container-fluid">
			<div class="section-title text-center">
                <h3 style="color:black">Blog</h3>
                <p style="color:black">Delicious and Helthey Food</p>
            </div><!-- end title -->
			
			<div class="row">
				<div class="col-md-4 col-sm-6 col-lg-4">
					<div class="post-box">
						<div class="post-thumb">
							<img src="<?php echo base_url('assets/uploads/blog-01.jpg') ?>" class="img-fluid" alt="post-img" />
							<div class="date">
								<span style="color:black">06</span>
								<span style="color:black">Aug</span>
							</div>
						</div>
						<div class="post-info">
							<h4 style="color:black">This Resturant Serve Halal Food</h4>
							<p style="color:black">We Deliver the Best Halal Food to the community</p>
							<ul>
                                <li>by admin</li>
                                <li>Apr 21, 2022</li>
                                <li><a href="#"><b> Comments</b></a></li>
                            </ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-lg-4">
					<div class="post-box">
						<div class="post-thumb">
							<img src="<?php echo base_url('assets/uploads/blog-02.jpg') ?>" class="img-fluid" alt="post-img" />
							<div class="date">
								<span>06</span>
								<span>Aug</span>
							</div>
						</div>
						<div class="post-info">
							<h4 style="color:black">This Resturant is situated just next to you</h4>
							<p style="color:black">We can delever the food to your home </p>
							<ul>
                                <li>by admin</li>
                                <li>Apr 21, 2022</li>
                                <li><a href="#"><b> Comments</b></a></li>
                            </ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-lg-4">
					<div class="post-box">
						<div class="post-thumb">
							<img src="<?php echo base_url('assets/uploads/blog-03.jpg') ?>" class="img-fluid" alt="post-img" />
							<div class="date">
								<span>06</span>
								<span>Aug</span>
							</div>
						</div>
						<div class="post-info">
							<h4 style="color:black">Indian-Pakistani_Bangladeshi</h4>
							<p style="color:black"> Over ALl South Asian Food</p>
							<ul>
                                <li>by admin</li>
                                <li>Apr 21, 2022</li>
                                <li><a href="#"><b> Comments</b></a></li>
                            </ul>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</div>