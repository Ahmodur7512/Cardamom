  <div id="about" class="section lb">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="message-box">                        
                        <h2 style="color: black;font-weight: bold;">Cardamom Indian Restaurant Alcester </h2>
                        <p style="color: black;"> Cardamom prides itself on serving you food that is totally satisfying in a relaxed atmosphere. We want our diners to fully enjoy the Cardamom experience in total comfort. Our staff are trained in delivering exceptional service whilst maintaining your needs first.

Our menu has been designed to offer you a full variety of food that is sure tickle your taste buds!

Many have been enjoying Cardamom throughout the years and still continue to visit us. Our Chef and his team are continuously improving our menu to forever delight and satisfy our guests.

We have recently refurbished our restaurant for maximum comfort for our diners. If you are yet to visit us, what are you waiting for?

Book your table today.

We really look forward to seeing you soon!</p>
						<ul>
							<li>satisfying in a relaxed atmosphere</li>
							<li>Our Staff are trained in  maintaining your needs first.</li>
							<li>Offer You A full variety of food. </li>
							<li>Refurbished our restaurant for maximum comfort for our diners.</li>
							<li>Book your table today.</li>
						</ul>
                        <a href="#" class="sim-btn hvr-radial-in"><span>Contact Us</span></a>
                    </div><!-- end messagebox -->
                </div><!-- end col -->

                <div class="col-md-6">
                    <div class="right-box-pro wow fadeIn">
                        <img src="assets/uploads/about_01.png" alt="" class="img-fluid img-rounded">
                    </div><!-- end media -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->
	
	<div class="section cont-box">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="inner-cont-box">
						<i class="flaticon-review"></i>
						<h3 class="counter-number">5000</h3>
						<h4>Client</h4>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="inner-cont-box">
						<i class="flaticon-alarm-clock"></i>
						<h3 class="counter-number">3000</h3>
						<h4>Time Of Work</h4>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="inner-cont-box">
						<i class="flaticon-idea"></i>
						<h3 class="counter-number">2000</h3>
						<h4>Ideas</h4>
					</div>
				</div>
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="inner-cont-box">
						<i class="flaticon-projector-screen"></i>
						<h3 class="counter-number">8000</h3>
						<h4>Project Done</h4>
					</div>
				</div>
			</div>
		</div>
	</div>