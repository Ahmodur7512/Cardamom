 <div id="menu" class="section lb">
 	
        <div class="container-fluid">
            <div class="section-title text-center">
                <h3 style="color:black">Menu</h3>
                <p style="color:black">Thinking of having a night in?</p>
            </div><!-- end title -->
            

            <div class="row">
				<div class="col-md-3">
                    <div class="card" style="background-color:#664a3f;color:#8dbd56;font-weight:bold">
						  <ul class="list-group list-group-flush">
						  	<?php 
						  	foreach($viewCat as $vc){

  	 
						  	 ?>
						  	 <a style="color:#8dbd56" href="<?php  echo base_url('Welcome/menuByCat/'.$vc->cat_id)  ?>">
						    <li class="list-group-item"><?php echo $vc->cat_name; ?></li>
						    </a>
						  </ul>
						<?php } ?>
						</div>
                </div><!-- end col -->

                <?php 
                
                foreach($viewFood as $vf){

                 ?>
                <div class="col-md-3" id="result">
                	
                    <div class="services-inner-box">
						<div class="ser-icon">
							<img style="height:250px" src="<?php echo base_url('assets/images/'.$vf->food_pic) ?>" class="img-fluid" alt="" />
						</div>
						<h2 style="color:black"><?php echo $vf->food_name ?></h2>
						<h3 style="color:black"><?php echo "$".$vf->price ?></h3>
						<?php 

						if ($this->session->userdata('user_id')) {
						 	// code...

						?>
					<a class="hvr-radial-in" href="<?php echo base_url('Welcome/addToCart/'.$vf->food_id) ?>" >Add To Cart</a>
				<?php }elseif($this->session->userdata('guest')){
					?>
					<a class="hvr-radial-in" href="<?php echo base_url('Welcome/addToCartAsGuest/'.$vf->food_id) ?>" >Add To Cart</a>

					<?php

				}
				else{
					?>
					<a class="hvr-radial-in" style="cursor: pointer;" href="<?php echo base_url('Welcome/login') ?>" >Add To Cart</a>
					<?php

						 } ?>
						
					</div>
                </div><!-- end col -->
            <?php } ?>
				
                </div><!-- end col -->
				
                </div><!-- end col -->
				
				
				
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->
    