<div id="gallery" class="section wb" style="">

		<div class="container-fluid">
			<div class="section-title text-center">
                <h3 style="color:black">Gallery</h3>

                <p style="color:black">We are here, with our Pride</p>
            </div><!-- end title -->
			
			<div class="gallery-menu text-center row">
				<div class="col-md-12">
					<div class="button-group filter-button-group">
						<button class="hvr-radial-in active" data-filter="*">Quality</button>
						<button class="hvr-radial-in" data-filter=".gal_a">Delicous</button>
						<button class="hvr-radial-in" data-filter=".gal_b">Best</button>
						<button class="hvr-radial-in" data-filter=".gal_c">Indian </button>
						<button class="hvr-radial-in" data-filter=".gal_d">Trust</button>
					</div>
				</div>
			</div>
			
			<div class="gallery-list row">
				<div class="col-md-4 col-sm-6 gallery-grid gal_a gal_b">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-01.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Vegetable Food</h3>
							<a href="assets/uploads/gallery_img-01.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_a gal_b">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-02.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Biriyani Food</h3>
							<a href="assets/uploads/gallery_img-02.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_b gal_c">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-03.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Rice Kari Food</h3>
							<a href="assets/uploads/gallery_img-03.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_b gal_a">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-04.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Beef Food</h3>
							<a href="assets/uploads/gallery_img-04.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_c gal_d">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-05.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Mutton Food </h3>
							<a href="assets/uploads/gallery_img-05.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_c gal_d">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-06.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Alster Food </h3>
							<a href="assets/uploads/gallery_img-06.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_c gal_b">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-07.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Special Food </h3>
							<a href="uploads/gallery_img-07.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_d gal_c">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-08.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Dessert Food </h3>
							<a href="uploads/gallery_img-08.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_d gal_a">
					<div class="gallery-single fix">
						<img src="<?php echo base_url('assets/uploads/gallery_img-09.jpg') ?>" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<h3>Organic Food </h3>
							<a href="uploads/gallery_img-09.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	 <div id="testimonials" class="section lb">
        <div class="container-fluid">
            <div class="section-title text-center">
                <h3 style="color:black">Testimonials</h3>
                <p style="color:black">We thanks for all our awesome testimonials! There are hundreds of our happy customers! </p>
            </div><!-- end title -->

            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="testi-carousel owl-carousel owl-theme">
                        <div class="testimonial align-items-center clearfix">
							<div class="testi-meta">
                                <img src="<?php echo base_url('assets/uploads/img-1.jpg') ?>" alt="" class="img-fluid">
                                <h4>James Fernando </h4>
                            </div>
                            <!-- end testi-meta -->
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Wonderful Support!</h3>
                                <p class="lead">They have got my project on time with the competition with a sed highly skilled, and experienced & professional team.</p>
                            </div>
                        </div>
                        <!-- end testimonial -->

                        <div class="testimonial align-items-center clearfix">
							<div class="testi-meta">
                                <img src="<?php echo base_url('assets/uploads/img-2.jpg') ?>" alt="" class="img-fluid">
                                <h4>Jacques Philips </h4>
                            </div>
                            <!-- end testi-meta -->
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Awesome Services!</h3>
                                <p class="lead">They have got my project on time with the competition with a sed highly skilled, and experienced & professional team.</p>
                            </div>
                        </div>
                        <!-- end testimonial -->

                        <div class="testimonial align-items-center clearfix">
							<div class="testi-meta">
                                <img src="<?php echo base_url('assets/uploads/img-3.jpg') ?>" alt="" class="img-fluid">
                                <h4>Venanda Mercy </h4>
                            </div>
                            <!-- end testi-meta -->
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Great & Talented Team!</h3>
                                <p class="lead">They have got my project on time with the competition with a sed highly skilled, and experienced & professional team. </p>
                            </div>
                        </div>
                        <!-- end testimonial -->
                        <div class="testimonial align-items-center clearfix">
							<div class="testi-meta">
                                <img src="<?php echo base_url('assets/uploads/img-1.jpg') ?>" alt="" class="img-fluid">
                                <h4>James Fernando </h4>
                            </div>
                            <!-- end testi-meta -->
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Wonderful Support!</h3>
                                <p class="lead">They have got my project on time with the competition with a sed highly skilled, and experienced & professional team.</p>
                            </div>
                        </div>
                        <!-- end testimonial -->

                        <div class="testimonial align-items-center clearfix">
							<div class="testi-meta">
                                <img src="<?php echo base_url('assets/uploads/img-2.jpg') ?>" alt="" class="img-fluid">
                                <h4>Jacques Philips </h4>
                            </div>
                            <!-- end testi-meta -->
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Awesome Services!</h3>
                                <p class="lead">They have got my project on time with the competition with a sed highly skilled, and experienced & professional team.</p>
                            </div>
                        </div>
                        <!-- end testimonial -->

                        <div class="testimonial align-items-center clearfix">
							<div class="testi-meta">
                                <img src="<?php echo base_url('assets/uploads/img-3.jpg') ?>" alt="" class="img-fluid">
                                <h4>Venanda Mercy <small>- Newyork City</small></h4>
                            </div>
                            <!-- end testi-meta -->
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Great & Talented Team!</h3>
                                <p class="lead">They have got my project on time with the competition with a sed highly skilled, and experienced & professional team. </p>
                            </div>
                        </div><!-- end testimonial -->
                    </div><!-- end carousel -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->