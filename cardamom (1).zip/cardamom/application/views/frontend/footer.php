<footer class="main-footer">
		<div class="container">
			<div class="row">
				<!-- end .modal-overlay -->
    
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="mb-3 img-logo">
						<a href="#">
							 <img src="<?php site_url('assets/images/logo.png') ?>" alt="">
						</a>
						<p>Our chefs have combined Bangladeshi and Indian flavours to give you a fusion taste. The ingredients we use are always fresh and we have a tradition of sticking to authentic cooking styles.
</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<h4 class="mb-4 ph-fonts-style foot-title">
						Recent Link
					</h4>
					<ul class="ph-links-column">
						<li><a href="<?php echo base_url('Welcome/index') ?>" class="text-black">Menu</a></li>
						<li><a href="<?php echo base_url('Welcome/about') ?>" class="text-black">About</a></li>
						<li><a href="<?php echo base_url('Welcome/gallary') ?>" class="text-black">Gallery</a></li>
						<li><a href="<?php echo base_url('Welcome/pricing') ?>" class="text-black">Pricing</a></li>
						<li><a href="<?php echo base_url('Welcome/blog') ?>" class="text-black">Blog</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<h4 class="mb-4 ph-fonts-style foot-title">
						Contact Us
					</h4>
					<div class="cont-box-footer">
						<div class="cont-line">
							<div class="icon-b">
								<i class="fa fa-map-signs" aria-hidden="true"></i>
							</div>
							<div class="cont-dit">
								<p>University House, Winston Churchill Ave, Portsmouth PO1 2UP, United Kingdom</p>
							</div>
						</div>
						<div class="cont-line">
							<div class="icon-b">
								<i class="fa fa-volume-control-phone" aria-hidden="true"></i>
							</div>
							<div class="cont-dit">
								<p><a href="#"> +44 7419 903136</a></p>
								<p><a href="#">+44 7419 903136</a></p>
							</div>
						</div>
						<div class="cont-line">
							<div class="icon-b">
								<i class="fa fa-envelope-o" aria-hidden="true"></i>
							</div>
							<div class="cont-dit">
								<p><a href="#">up2045271@myport.ac.uk</a></p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<h4 class="mb-4 ph-fonts-style foot-title">
						
					</h4>
					<p class="ph-fonts-style_p">
					</p>
					<div class="media-container-column" data-form-type="formoid">
						<div data-form-alert="" class="align-center" hidden="">
						</div>

						
					</div>

				</div>
			</div>
		</div>
	</footer>

    <div class="copyrights">
        <div class="container-fluid">
            <div class="footer-distributed">
                <div class="footer-left">
                    <p class="footer-links">
          <a href="<?php echo base_url('Welcome/index') ?>" class="text-black">Menu</a>
					<a href="<?php echo base_url('Welcome/about') ?>" class="text-black">About</a>
					<a href="<?php echo base_url('Welcome/gallary') ?>" class="text-black">Gallery</a>
					<a href="<?php echo base_url('Welcome/pricing') ?>" class="text-black">Pricing</a>
					<a href="<?php echo base_url('Welcome/blog') ?>" class="text-black">Blog</a>
					
                    </p>
                    <p class="footer-company-name">All Rights Reserved. &copy; 2022 <a href="#">Ports Mouth</a> </p>
                </div>
            </div>
        </div><!-- end container -->
    </div><!-- end copyrights -->

    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>

    <!-- ALL JS FILES -->
    <script src="<<?php echo base_url('assets/js/all.js') ?>"></script>
	<!-- Camera Slider -->
	<script src="<?php echo base_url('assets/js/jquery.mobile.customized.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/jquery.easing.1.3.js') ?>"></script> 
	<script src="<?php echo base_url('assets/js/parallaxie.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/headline.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/owl.carousel.js') ?>"></script>
	<script src="<?php echo base_url('assets/js/jquery.nicescroll.min.js') ?>"></script>
	<!-- Contact form JavaScript -->
    <script src="<?php echo base_url('assets/js/jqBootstrapValidation.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/contact_me.js') ?>"></script>
    <!-- ALL PLUGINS -->
    <script src="<?php echo base_url('assets/js/custom.js') ?>"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

   
    	<script type="text/javascript">
  function addToCart(food_id){
  	console.log(food_id);

      $.ajax({
        method:"GET",
        url:"<?php echo base_url('Welcome/countToCart') ?>",
        data:{food_id:food_id},
        cache:false,
        success:function(val){
          $('#count_cart').html(val);

          
        }
        error:console.log(error);

      });
  }
  function validateForm() {
  let x = document.forms["myForm"]["profile_pic"].value;
  if (x == "") {
    alert("File must be filled out");
    return false;
  }
}
function validateForm1() {
  let x = document.forms["myForm1"]["cover_pic"].value;
  if (x == "") {
    alert("File must be filled out");
    return false;
  }
}
</script>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
/* for this codepen */ 
document.body.removeAttribute( "translate" ); 

</script>
<script>
$(document).ready(function(){

 

 function load_data(query)
 {
  $.ajax({
   url:"<?php echo base_url('Welcome/search');?>",
   method:"POST",
   data:{query:query},
   success:function(data){
    $('#result').html(data);
   }
  })
 }

 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>


    

</body>
</html>