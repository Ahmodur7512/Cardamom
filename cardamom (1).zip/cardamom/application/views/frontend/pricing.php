<div id="pricing" class="section lb">
		<div class="container-fluid">
			<div class="section-title text-center">
                <h3  style="color:black">Our Pricing</h3>
                <p style="color:black">We thanks for all our awesome testimonials! There are hundreds of our happy customers! </p>
            </div><!-- end title -->
			
			<div class="row">
				<?php 
                
                foreach($viewPackage as $vp){

				 ?>
				<div class="col-md-4 col-sm-6">
					<div class="pricingTable pri-bg-a">
						<div class="pricingTable-header">
							<h3 style="color:black" class="title"><?php echo $vp->package_name ?></h3>
							<div class="price-value">
								<div class="value">
									<span class="amount">$<?php echo $vp->price ?></span>
									<span class="month">per Month</span>
								</div>
							</div>
						</div>
						<ul class="pricing-content">
							<li><?php echo $vp->feature1 ?></li>
							<li><?php echo $vp->feature2 ?></li>
							<li><?php echo $vp->feature3 ?></li>
							<li><?php echo $vp->feature4 ?></li>
							<li><?php echo $vp->feature5 ?></li>
						</ul>
						<a href="<?php echo base_url('Welcome/contact') ?>" class="hvr-radial-in pricingTable-signup"><i class="fa fa-dot-circle-o"></i>Contact Now</a>
					</div>
				</div>
			<?php } ?>

				

				
			</div>
			
		</div>
	</div>