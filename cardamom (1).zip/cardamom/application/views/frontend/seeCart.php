<style>
.pagination {
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
<noscript>
				<div class="alert alert-block span10" >
					
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Members</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<div>
      <?php if ($this->session->flashdata('class')): ?>
        <div class="alert <?php echo $this->session->flashdata('class') ?> alert-dismissible" role="alert">

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>

  </button>
  <?php echo $this->session->flashdata('message'); ?>
  
    
</div>
              
            <?php endif; ?>
    </div>
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
							<center>
							<h1 style="color:black">Your Card</h1>
							</center>
						  <thead>
							  <tr>
								  <th>No</th>
								  <th>Food Name</th>
								  <th>Image</th>
								  
								  <th>Quantity</th>
								  <th>Price</th>
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php 
						  	$i=0;
						  	$totalPrice=0;
						  	if ($seeCart) {
						  		// code...
						  	
						  	foreach($seeCart as $sc){
						  		$i++;

  	 
						  	 ?>
							<tr>
								<td class="center"><?php echo $i; ?></td>
								<?php 
								$foodDetails['name']=$this->modAdmin->fetchFoodDetails($sc->food_id);
								$total=$foodDetails['name']->price*$sc->quant;
								$totalPrice += $total
								 ?>
								<td class="center"><?php echo $foodDetails['name']->food_name ?></td>
								
								
								<td class="center">
									<img style="width: 150px;height: 80px;" src="<?php echo base_url('assets/images/'.$foodDetails['name']->food_pic) ?>">
								</td>
								<td class="center"><?php echo "".$sc->quant ?></td>
								<?php 


                

								 ?>
								<td class="center"><?php echo "$".$total ?></td>

								<td class="center">
									
									
									<a class="btn btn-danger" href="<?php echo site_url('Welcome/deleFoodFromCart/'.$sc->cart_id) ?>">
                    <i class="fa fa-trash" aria-hidden="true"></i>
									</a>
								</td>

							</tr>
						<?php } 
					}
						?>
						<tr>
							<td class="center  btn"  style="font-weight: bold;color:#dc3545">Total Price</td>
							<td class="center"></td>
							<td class="center"></td>
							<td class="center btn" style="font-weight:bold;color:#dc3545"><?php echo '$'.$totalPrice; ?></td>
						</tr>
						<tr>
							<td class="center  btn btn-danger"  style="ont-weight:bold;color:white">
								<a  style="font-weight:bold;color:white" href="<?php echo base_url('Welcome/index') ?>">
							Back
							</a>
						</td>
							<td class="center "> 
								
							 </td>
							<td class="center btn btn-success">
								<a  style="font-weight:bold;color:white" href="<?php echo base_url('Welcome/payByCash/'.$totalPrice) ?>">
							Pay By Cash
							</a>
							</td>
							<td class="center "> 
								
							 </td>
							<td class="center btn btn-success" >
								<a style="font-weight:bold;color:white" href="<?php echo base_url('Welcome/payment/'.$totalPrice) ?>">
							Pay By Card

							</a>
						</td>
						</tr>
						
							
						
							
							
						  </tbody>

					  </table>
					  <div class="pagination">
  
  <a href="#" ></a>
  
</div>
					          
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

		