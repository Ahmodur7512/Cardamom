	<section id="home" class="main-banner">
		
		<div id='slideshow-container' class='header'>
  <div id='slideshow-textbox' class='textbox-ctr'>
    <h2>Example</h2>
    <p>Cardamom Indian Restaurant is located in the market town of Alcester, Warwickshire.

We have been serving fine Indian cuisine backed up by exceptional service to the people of Alcester and also passing tourists to the area for many years! We offer a great tasting Ala Carte menu and also a convenient takeaway/delivery service! If you are yet to experience Cardamom, what are you waiting for?

</p>
    <p><a href="https://en.wikipedia.org/wiki/Ken_Burns_effect" target="_blank">Click here</a> to learn more about the Ken Burns effect.</p>
  </div>

  <img class="slideshow-img-anim" id="slideshow-img-1" src="<?php echo site_url('assets/uploads/slider-01.jpg') ?>">
  

  <img class="slideshow-img-anim" id="slideshow-img-2" src="<?php echo site_url('assets/uploads/slider-02.jpg') ?>">

  <img class="slideshow-img-anim" id="slideshow-img-3" src="<?php echo site_url('assets/uploads/slider-03.jpg') ?>">

  <img class="slideshow-img-anim" id="slideshow-img-4" src="<?php echo site_url('assets/uploads/slider-02.jpg') ?>">

</div>
		
	</section>