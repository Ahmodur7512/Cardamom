<div id="content" class="span10">
      
      
      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i> 
        </li>
        <li>
          <i class="icon-edit"></i>
          <a href="#">Forms</a>
        </li>
      </ul>
      
      <div class="row-fluid sortable">
        <div class="box span12">
          <div class="box-header" data-original-title>
            <h2><i class="halflings-icon white edit"></i><span class="break"></span>Add Food</h2>

            <div class="box-icon">
              <a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
              <a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
              <a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
            </div>
          </div>
          <div class="box-content">
             <div>
      <?php if ($this->session->flashdata('class')): ?>
        <div class="alert <?php echo $this->session->flashdata('class') ?> alert-dismissible" role="alert">

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>

  </button>
  <?php echo $this->session->flashdata('message'); ?>
  
    
</div>
              
            <?php endif; ?>
    </div>
            <form class="form-horizontal"  method="post"  action="<?php echo site_url('Admin/addFood') ?>"  enctype="multipart/form-data">
              <fieldset>
              <div class="control-group">
                <label class="control-label" for="fileInput">Food Name</label>

                <div class="controls">
                <input type="text" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" name="food_name">
                </div>
              </div>
              

              <div class="control-group">
                <label class="control-label" for="fileInput">Picture</label>
                <div class="controls">
                <input class="input-file uniform_on" id="fileInput" type="file" name="food_pic">
                </div>
              </div>
              <div class="control-group">
                <label class="control-label" for="selectError3">Category</label>
                <div class="controls">
                  <select id="selectError3" name="food_category">
                    <?php 
                    if ($viewCat) {
                      // code...
                    
                foreach($viewCat as $vc){

     
                 ?>
                  <option value="<?php echo $vc->cat_id ?>"><?php echo $vc->cat_name ?></option>
                  
                <?php }
              } ?>
                  </select>
                </div>
                </div> 
                <div class="control-group">
                <label class="control-label" for="fileInput">Total Stock</label>

                <div class="controls">
                <input type="number" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" name="stock">
                </div>
              </div>         
              <div class="control-group">
                <label class="control-label" for="fileInput">Price</label>

                <div class="controls">
                <input type="number" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" name="price">
                </div>
              </div>
              <div class="form-actions">
                <button type="submit" class="btn btn-primary">Add Food</button>
                <button type="reset" class="btn">Cancel</button>
              </div>
              </fieldset>
            </form>   

          </div>
        </div><!--/span-->

      </div><!--/row-->

      
      
      
    

  </div><