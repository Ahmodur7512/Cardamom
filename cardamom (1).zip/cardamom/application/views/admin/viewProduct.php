<style>
.pagination {
  display: inline-block;
}

.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
}

.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
<noscript>
				<div class="alert alert-block span10" >
					
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Members</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<div>
      <?php if ($this->session->flashdata('class')): ?>
        <div class="alert <?php echo $this->session->flashdata('class') ?> alert-dismissible" role="alert">

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>

  </button>
  <?php echo $this->session->flashdata('message'); ?>
  
    
</div>
              
            <?php endif; ?>
    </div>
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>No</th>
								  <th>Food Name</th>
								  <th>Food Category</th>
								  <th>Price</th>
								  <th>Stock</th>
								  <th>Image</th>
								  
								  <th>Actions</th>
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php 
						  	foreach($viewFood as $vc){

  	 
						  	 ?>
							<tr>
								<td class="center"><?php echo $vc->food_id ?></td>
								<td class="center"><?php echo $vc->food_name ?></td>
								<td class="center"><?php
								foreach($viewCat as $cat){
									if($cat->cat_id==$vc->food_category){
										echo $cat->cat_name;
									}
								}
								  ?></td>
								<td class="center"><?php echo "$".$vc->price ?></td>
								<td class="center"><?php echo $vc->stock ?></td>
								
								<td class="center">
									<img style="width: 150px;height: 80px;" src="<?php echo base_url('assets/images/'.$vc->food_pic) ?>">
								</td>
								<td class="center">
									<a class="btn btn-success" href="<?php echo site_url('admin/editFood/'.$vc->food_id) ?>">
										<i class="fa fa-edit"></i> 
									</a>
									
									<a class="btn btn-danger" href="<?php echo site_url('admin/deleFood/'.$vc->food_id) ?>">
                    <i class="fa fa-trash" aria-hidden="true"></i>
									</a>
								</td>
							</tr>
						<?php } ?>
							
						
							
							
						  </tbody>

					  </table>
					  <div class="pagination">
  
  <a href="#" ><?php echo $links; ?></a>
  
</div>
					          
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

		