<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>

			<div class="row-fluid">
				
				<div class="span3 statbox purple" onTablet="span6" onDesktop="span3">
					<div class="boxchart"></div>
					<div class="number">
                       <?php 
                    
                    $countFood=$this->modAdmin->count_food();
                    $count_category=$this->modAdmin->count_category();
                    $count_Order=$this->modAdmin->count_Order();
                    $count_Package=$this->modAdmin->count_Package();
                    echo count($countFood);

                        ?>
						<i class="icon-arrow-up"></i></div>
					<div class="title">Food</div>
					<div class="footer">
						
					</div>	
				</div>
				<div class="span3 statbox green" onTablet="span6" onDesktop="span3">
					<div class="number"><?php 
                       echo count($count_category);
					 ?><i class="icon-arrow-up"></i></div>
					<div class="title">Category</div>
					<div class="footer">
						
					</div>
				</div>
				<div class="span3 statbox blue noMargin" onTablet="span6" onDesktop="span3">
					<div class="number"><?php 
                       echo count($count_Order);
					 ?><i class="icon-arrow-up"></i></div>
					<div class="title">Orders</div>
					<div class="footer">
					</div>
				</div>
				<div class="span3 statbox yellow" onTablet="span6" onDesktop="span3">
					<div class="number"><?php 
                       echo count($count_Package);
					 ?><i class="icon-arrow-down"></i></div>
					<div class="title">Packages</div>
					<div class="footer">
					</div>
				</div>	
				
			</div>		

			
			
			<div class="row-fluid">
				
				
				
				
				
				
			
			</div>
				
			</div>		
			
			
			
       

	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
		
	
	
	
	
	<div class="clearfix"></div>