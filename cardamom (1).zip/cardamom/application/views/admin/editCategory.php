<!-- start: Content -->
			<div id="content" class="span10" style="height:1000px">
			
			
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Edit Category</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					 <div>
      <?php if ($this->session->flashdata('class')): ?>
        <div class="alert <?php echo $this->session->flashdata('class') ?> alert-dismissible" role="alert">

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>

  </button>
  <?php echo $this->session->flashdata('message'); ?>
  
    
</div>
              
            <?php endif; ?>
    </div>
					<div class="box-content">
						<form name="myForm" class="form-horizontal" style="margin-top:5%" action="<?php echo base_url('admin/updateCategory') ?>" onsubmit="return validateForm()" method="post">
						  <fieldset>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Category Name </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $category[0]['cat_name'] ?>" name="cat_name">
							   <input type="hidden"  value="<?php echo $category[0]['cat_id'] ?>" name="cat_id">

								
							  </div>
							</div>
							

							         
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Update </button>
							  
							</div>
						  </fieldset>
						</form>   

					</div>
				</div><!--/span-->

			</div><!--/row-->			
       

	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		






































