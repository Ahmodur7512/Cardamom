<noscript>
				<div class="alert alert-block span10" >
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
			
			<!-- start: Content -->
			<div id="content" class="span10" style="height:1000px">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Tables</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white user"></i><span class="break"></span>Members</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					<div class="box-content">
						<div>
      <?php if ($this->session->flashdata('class')): ?>
        <div class="alert <?php echo $this->session->flashdata('class') ?> alert-dismissible" role="alert">

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>

  </button>
  <?php echo $this->session->flashdata('message'); ?>
  
    
</div>
              
            <?php endif; ?>
    </div>
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Number</th>
								  <th>Customer Name</th>
								  <th>Food Name</th>
								  <th>Food Quantity</th>
								  <th>Payment</th>
								  
								  
								  <th>Delivery Status</th>
							  </tr>
						  </thead>   
						  <tbody>
						  	<?php 
						  	$i=0;
						  	foreach($viewOrder as $vo){
                $i++;
  	 
						  	 ?>
							<tr>
								<td class="center"><?php echo $i; ?></td>
								<?php 
										$foodDetails['food']=$this->modAdmin->fetchFoodDetails($vo->food_id);
										$userDetails['name']=$this->modAdmin->fetchUserDetails($vo->user_id);


								 ?>
								<td class="center"><?php echo $userDetails['name']->user_name ?></td>
								<td class="center"><?php echo $foodDetails['food']->food_name ?></td>
								<td class="center"><?php echo $vo->quant ?></td>
								<td class="center"><?php 
								if ($vo->payment==0) {
									?>
									<span style="color:green">Card Payment</span>
									<?php
								}else{
								 ?>
                <span style="color:blue;">Cash Payment</span>
								 </td><?php
								} ?>
								
								<td class="center">
									<?php 
                  
                  if ($vo->delivery==0) {
                  	// code...
                  	?>
                  	<a class="btn btn-alert" href="<?php echo site_url('admin/makeOrderReady/'.$vo->order_id) ?>">
										Not Ready</i> 
									</a>
                  	<?php
                  }elseif($vo->delivery==1){
                  	?>
                  	<a class="btn btn-success" href="<?php echo site_url('admin/makeOrderForDelete/'.$vo->order_id) ?>">
										 Ready</i>
                  	<?php
                  }else{

									 ?>
									 <a class="btn btn-success" href="<?php echo site_url('admin/deleteOrder/'.$vo->order_id) ?>">
										<i style="color:red" class="fa fa-trash"></i> 
									</a>
									<?php } ?>
									
									
									
								</td>
							</tr>
						<?php } ?>
							
						
							
							
						  </tbody>
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->

		