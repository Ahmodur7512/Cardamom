<!-- start: Content -->
			<div id="content" class="span10" style="height:1000px">
			
			
			<div class="row-fluid sortable">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon white edit"></i><span class="break"></span>Edit Category</h2>
						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
						</div>
					</div>
					 <div>
      <?php if ($this->session->flashdata('class')): ?>
        <div class="alert <?php echo $this->session->flashdata('class') ?> alert-dismissible" role="alert">

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>

  </button>
  <?php echo $this->session->flashdata('message'); ?>
  
    
</div>
              
            <?php endif; ?>
    </div>
					<div class="box-content">
						<form name="myForm" class="form-horizontal" style="margin-top:5%" action="<?php echo base_url('admin/updatePackage') ?>"  method="post">
						  <fieldset>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Package Name </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['package_name'] ?>" name="package_name">
							   <input type="hidden"  value="<?php echo $package[0]['price_id'] ?>" name="price_id">

								
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Price </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['price'] ?>" name="price">

								
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Feature 1 </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['feature1'] ?>" name="feature1">

								
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Feature 2 </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['feature2'] ?>" name="feature2">

								
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Feature 3 </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['feature3'] ?>" name="feature3">

								
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Feature 4 </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['feature4'] ?>" name="feature4">

								
							  </div>
							</div>
							<div class="control-group">
							  <label class="control-label" for="typeahead">Feature 5 </label>
							  <div class="controls">
							   <input type="text"  value="<?php echo $package[0]['feature5'] ?>" name="feature5">

								
							  </div>
							</div>
							

							         
							
							<div class="form-actions">
							  <button type="submit" class="btn btn-primary">Update </button>
							  
							</div>
						  </fieldset>
						</form>   

					</div>
				</div><!--/span-->

			</div><!--/row-->			
       

	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		






































