<?php 

    class ModAdmin extends CI_Model{
          

        public function checkCategory($data){
   		$array = array('cat_name' => $data['cat_name']);
   		return $this->db->get_where('tbl_category',$array);
   	}
    public function checkPackage($data){
        $array = array('package_name' => $data['package_name']);
        return $this->db->get_where('tbl_pricing',$array);
    

    }
   	public function addCategory($data){
   		return $this->db->insert('tbl_category',$data);
   	}

    public function addPackage($data){
        return $this->db->insert('tbl_pricing',$data);
    }

    public function fetch_category(){

      $this->db->order_by("cat_id", "ASC");
      $query = $this->db->get("tbl_category");
      return $query->result();

    }
    public function fetch_pricing(){

      $this->db->order_by("price_id", "ASC");
      $query = $this->db->get("tbl_pricing");
      return $query->result();

    }
    public function fetch_order(){

      $this->db->order_by("order_id", "ASC");
      $query = $this->db->get("tbl_Order");
      return $query->result();

    }

    public function chekCategoryById($id){
         $array = array('cat_id' => $id);
         return $this->db->get_where('tbl_category',$array)->result_array();
    }

    public function chekPackageById($id){
        $array = array('price_id' => $id);
         return $this->db->get_where('tbl_pricing',$array)->result_array();
   

    }

    public function updateCategory($data){
         $this->db->where('cat_id',$data['cat_id']);
         
         return $this->db->update('tbl_category',$data);
      }
    public function updatePackage($data){
         $this->db->where('price_id',$data['price_id']);
         
         return $this->db->update('tbl_pricing',$data);
      }
    public function deleteCategory($id){
         $this->db->where('cat_id',$id);
         return $this->db->delete('tbl_category');
      }
    public function deletePackage($id){
        $this->db->where('price_id',$id);
        return $this->db->delete('tbl_pricing');
      

    }
    
    public function addProduct($data){
      return $this->db->insert('tbl_food',$data);
    }
    public function addMessage($data){
      return $this->db->insert('tbl_contact',$data);
    }
    public function get_count() {
        return $this->db->count_all("tbl_food");
    }
    public function fetch_food($limit,$start){
//Pagination Start
        $this->db->limit($limit, $start);
       $query = $this->db->get("tbl_food");
       if ($query->num_rows() > 0) {
           foreach ($query->result() as $row) {
               $data[] = $row;
           }
           return $data;
       }
       return false;




        //Pagination Ends



       /*       $this->db->limit($limit, $start);
              $query = $this->db->get("tbl_food");

      return $query->result(); */

    }
    public function fetch_all_food(){

        $query=$this->db->get("tbl_food");
        if ($query->num_rows() > 0) {
           foreach ($query->result() as $row) {
               $data[] = $row;
           }
           return $data;
       }
       return false;

    }
    public function fetch_all_food_by_Category($id){
        $array=array(
            'food_category'=>$id
        );
        $query=$this->db->get_where("tbl_food",$array);
        if ($query->num_rows() > 0) {
           foreach ($query->result() as $row) {
               $data[] = $row;
           }
           return $data;
       }
       return false;

    }
    public function fetch_all_package(){

        $query=$this->db->get("tbl_pricing");
        if ($query->num_rows() > 0) {
           foreach ($query->result() as $row) {
               $data[] = $row;
           }
           return $data;
       }
       return false;

    }public function fetch_Message(){

        $query=$this->db->get("tbl_contact");
        if ($query->num_rows() > 0) {
           foreach ($query->result() as $row) {
               $data[] = $row;
           }
           return $data;
       }
       return false;

    }
    public function chekFoodById($id){
         $array = array('food_id' => $id);
         return $this->db->get_where('tbl_food',$array)->result_array();
    }

    public function updateProduct($data,$food_id){
         $this->db->where('food_id',$food_id);
         return $this->db->update('tbl_food',$data);
      }
      public function makeOrderReady($id){
         $this->db->where('order_id',$id);
         $data['delivery']=1;
         return $this->db->update('tbl_Order',$data);
      }
      public function makeOrderForDelete($id){
         $this->db->where('order_id',$id);
         $data['delivery']=2;
         return $this->db->update('tbl_Order',$data);
      }
    public function deleteFood($id){
         $this->db->where('food_id',$id);
         return $this->db->delete('tbl_food');
      }
      public function deleteOrder($id){
         $this->db->where('order_id',$id);
         return $this->db->delete('tbl_Order');
      }
    public function permitlogin($data){
      
      
      return $this->db->get_where('tbl_admin',$data)->result_array();
    }
    public function chkRegister($data){
        
          $this->db->select('user_id');
          $this->db->from('tbl_user');
          $this->db->where('user_email', $data['user_email']);
          $query = $this->db->get();
          return $num = $query->num_rows();
       }
       public function checkCartExistance($data){
        
          
          
          $array=array(
            'user_id'=>$data['user_id'],
            'food_id'=>$data['food_id']
          );
          $query = $this->db->get_where('tbl_cart',$array);
          return $num = $query->num_rows();
       }
    public function addUser($data){
          return $this->db->insert('tbl_user',$data);
    }
    public function user_permitlogin($data){
      
      return $this->db->get_where('tbl_user',$data)->result_array();
    }
    public function countToCart($data){
      return $this->db->insert('tbl_cart',$data);
     /* $output='';
      if ($qry) {
        $qry=$this->db->select('*')->from('tbl_cart')->where($data)->get()->result();
        $output .= '<span>'.sizeof($qry).'</span>';
      }
      return $output; */

    }
    public function updatecountToCart($quant,$cart_id){
        $array=array(
            'quant'=>$quant+1
        );
        $array1=array(
             'cart_id'=> $cart_id
        );
        $this->db->where($array1);


        $q=$this->db->update('tbl_cart',$array);
        return $q;

    }
    public function count_cart_for_user($user_id){
      $qry=$this->db->select('*')->from('tbl_cart')->where('user_id',$user_id)->get()->result();
      return $qry;
    }
    public function count_cart_for_guest(){
      $qry=$this->db->select('*')->from('tbl_cart')->where('user_id',null)->get()->result();
      return $qry;
    }
    public function fetch_cart(){
      $array = array('user_id' => $this->session->userdata('user_id'));
      $query=$this->db->where($array);
       $query=$this->db->get('tbl_cart');
       if ($query->num_rows()>0) {
             foreach ($query ->result() as $row) {
                $data[]=$row;
             }
             return $data;
         }
         return false;

    }
    public function fetch_cart_quantity($food_id){

        $array = array('user_id'=>null,'food_id'=>$food_id);

         return $this->db->get_where('tbl_cart',$array)->row();

      
         

    }
    public function fetch_cart_quantity_forUser($food_id,$user_id){

        $array = array('user_id'=>$user_id,'food_id'=>$food_id);

         return $this->db->get_where('tbl_cart',$array)->row();

      
         

    }

    public function fetch_cartAsGuest(){
      $array = array('guest' => 1);
      $query=$this->db->where($array);
       $query=$this->db->get('tbl_cart');
       if ($query->num_rows()>0) {
             foreach ($query ->result() as $row) {
                $data[]=$row;
             }
             return $data;
         }
         return false;

    }
    public function fetchFoodDetails($id){
         $array = array('food_id' => $id);
         return $this->db->get_where('tbl_food',$array)->row();

      }
      public function fetchUserDetails($id){
         $array = array('user_id' => $id);
         return $this->db->get_where('tbl_user',$array)->row();

      }
    public function deletecart($id){
        $this->db->where('cart_id',$id);
         return $this->db->delete('tbl_cart');
     

    }
    public function fetch_data($query)
 {


  $this->db->select("*");
  $this->db->from('tbl_food');
  

  if($query != '')
  {
   $this->db->like('food_name', $query);
  }
  $this->db->order_by('food_id', 'DESC')->limit(1);
  return $this->db->get();
 }

 public function insertOrder($id){
    $q = $this->db->get_where('tbl_cart',$id)->result(); 
    // get first table
    
    foreach($q as $r) { // loop over results
        $data['user_id']=$r->user_id;
        $data['food_id']=$r->food_id;
        $data['quant']=$r->quant;

        $this->db->insert('tbl_Order', $data); // insert each row to another table
        $this->db->delete('tbl_cart', $data); // insert each row to another table
    }

 }
 public function insertOrderAsGuest($id){
    $q = $this->db->get_where('tbl_cart',$id)->result(); 
    // get first table
    
    foreach($q as $r) { // loop over results
        $data['user_id']=null;
        $data1['user_id']=null;
        $data['food_id']=$r->food_id;
        $data['quant']=$r->quant;
        $data['guest']=1;

        $this->db->insert('tbl_Order', $data); // insert each row to another table
        $this->db->delete('tbl_cart', $data1); // insert each row to another table
    }

 }
 public function insertOrderByCash($id){
    $q = $this->db->get_where('tbl_cart',$id)->result(); 
    // get first table
    
    foreach($q as $r) { // loop over results
        $data['user_id']=$r->user_id;
        $data1['user_id']=$r->user_id;
        $data['food_id']=$r->food_id;
        $data['quant']=$r->quant;
        $data['payment']=2;

        $this->db->insert('tbl_Order', $data); // insert each row to another table
        $this->db->delete('tbl_cart', $data1); // insert each row to another table
    }

 }
 public function insertGuestOrderByCash($id){
    $q = $this->db->get_where('tbl_cart',$id)->result(); 
    // get first table
    
    foreach($q as $r) { // loop over results
        $data['user_id']=null;
        $data1['user_id']=null;
        $data['food_id']=$r->food_id;
        $data['quant']=$r->quant;
        $data['payment']=2;
        $data['guest']=1;

        $this->db->insert('tbl_Order', $data); // insert each row to another table
        $this->db->delete('tbl_cart', $data1); // insert each row to another table
    }

 }

 public function count_food(){
      $qry=$this->db->select('*')->from('tbl_food')->get()->result();
      return $qry;
    }public function count_category(){
      $qry=$this->db->select('*')->from('tbl_category')->get()->result();
      return $qry;
    }public function count_Order(){
      $qry=$this->db->select('*')->from('tbl_Order')->get()->result();
      return $qry;
    }public function count_Package(){
      $qry=$this->db->select('*')->from('tbl_pricing')->get()->result();
      return $qry;
    }
    public function count_message(){
      $qry=$this->db->select('*')->from('tbl_contact')->get()->result();
      return $qry;
    }
 





    }



